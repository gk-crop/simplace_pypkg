Version 4.0.1
~~~~~~~~~~~~~
 * Replaced dependency from JPype1-py3 with JPype1 for python 3.x

Version 4.0.0
~~~~~~~~~~~~~
 * Compatible with Simplace V4.0
 * Increased version number to have the same version as Simplace 

Version 0.2.6
~~~~~~~~~~~~~
 * Compatible with Simplace V3.4
 * Corrected documentation.

Version 0.2.5
~~~~~~~~~~~~~
 * Add all jars from lib directory to classpath for better forward compatibility.

Version 0.2.4
~~~~~~~~~~~~~
 * Compatible with new Simplace rule engine (jexl 3)

Version 0.2.3
~~~~~~~~~~~~~
 * Compatible with Simplace V3.3

Version 0.2.2
~~~~~~~~~~~~~
 * Added class SimplaceInstance for object oriented approach.
 * Added Changelog file.
 
Version 0.2.1
~~~~~~~~~~~~~
 * Improved documentation
 * Bugfixes

Version 0.2.0
~~~~~~~~~~~~~
 * Small changes

Version 0.1.9
~~~~~~~~~~~~~
 * Small changes

Version 0.1.8
~~~~~~~~~~~~~
 * Added documentation
 * Added classifiers in package description

Version 0.1.7
~~~~~~~~~~~~~
 * Small changes

Version 0.1.6
~~~~~~~~~~~~~
 * Compatible with Python 2.x and Python 3.x

Version 0.1.5
~~~~~~~~~~~~~
 * Small changes

Version 0.1.4
~~~~~~~~~~~~~
 * Small changes

Version 0.1.3
~~~~~~~~~~~~~
 * Small changes

Version 0.1.2
~~~~~~~~~~~~~
 * Small changes

Version 0.1.1
~~~~~~~~~~~~~
 * Small changes

Version 0.1
~~~~~~~~~~~~~
Initial version